<template>
    <div>
      促销管理
    </div>
</template>

<script>
    export default {
        name: "promotion"
    }
</script>

<style scoped>

</style>
