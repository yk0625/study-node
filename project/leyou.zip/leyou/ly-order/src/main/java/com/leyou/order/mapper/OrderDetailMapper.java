package com.leyou.order.mapper;

import com.leyou.common.mapper.BaseMapper;
import com.leyou.order.pojo.OrderDetail;

public interface OrderDetailMapper extends BaseMapper<OrderDetail> {
}
