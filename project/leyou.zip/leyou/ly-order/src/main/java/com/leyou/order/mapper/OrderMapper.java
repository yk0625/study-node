package com.leyou.order.mapper;

import com.leyou.common.mapper.BaseMapper;
import com.leyou.order.pojo.Order;

public interface OrderMapper extends BaseMapper<Order> {
}
