package com.leyou.item.mapper;

import com.leyou.common.mapper.BaseMapper;
import com.leyou.item.pojo.Category;

public interface CategoryMapper extends BaseMapper<Category> {
}
