package com.leyou.auth.constants;

public abstract class JwtConstants {
    public static final String JWT_KEY_ID = "id";
    public static final String JWT_KEY_USER_NAME = "username";
}